# WordPress Composer Fork

If you're looking for more information on using composer and WordPress together, go check out http://composer.rarst.net

If you're looking for WordPress core, the core package is now at https://github.com/johnpbloch/wordpress-core

